﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace homework1.MariaVardanyan
{
    internal class SelectionSort
    {
        public void Sort(int[] array,int size, int start) {
            int min = array[start];
            int index=start;
            for (int i = start; i < size; i++) {
                if (array[i] <= min)
                {
                    min = array[i];
                    index = i;
                }
                
            
            }
            int c = array[start];
            array[start] = min;
            array[index] = c;
            start += 1;
            if (start < size)
            {
                Sort(array, size, start);
            }else
            {
                Console.WriteLine("Sorting ended!");
            }
        }
        public void printArray(int[] array, int size)
        {
            foreach (int i in array)
            {
                Console.WriteLine(i);
            }
        }
    }
}
