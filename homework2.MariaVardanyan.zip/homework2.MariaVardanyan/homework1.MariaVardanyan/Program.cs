﻿using System;
using homework1.MariaVardanyan;
class Sample
{   

    static DateTime thisDate = DateTime.Now;

    public static void Main()
    {

        //All the functions was written from myself mr. Yeprikyan, no chatgpt))
        Console.Clear();
        Console.WriteLine(" Sorting Code started at .. ");
        Console.WriteLine(thisDate.ToString()); 
        int[] array = { 1, 2, -6, 10, 5, -45, 17 };
        int size = array.Length;
        int start = 0;
        SelectionSort sort = new SelectionSort();
        sort.Sort(array, size, start);
        sort.printArray(array,size);
        Console.WriteLine("Sorting Code ended at .. ");
        Console.WriteLine(thisDate.ToString());


        Console.WriteLine("Starting Queue..");
        int max = 100;
        List<int> que= new List<int>(max);
        Queque q= new Queque();
       
        q.push(que, 7, max);
        q.push(que, 8, max);
        q.pull(que);
        q.printArray(que);
        q.peek(que);
    }
}
